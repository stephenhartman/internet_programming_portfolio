CREATE TABLE Cars
(
carID INT NOT NULL PRIMARY KEY AUTO_INCREMENT,
carYear int,
carMake varchar(255),
carModel varchar(255),
carOption varchar(255),
carVIN varchar(255),
carStyle varchar(255),
carMileage int,
carOrigin varchar(255),
carWeight int,
carHP int
)